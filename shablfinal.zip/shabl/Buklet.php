<?php
session_start();
$login=$_SESSION['user']['login'];
$flag=0;
if ($_SESSION['user']['login'])
{
    $flag=1;
}

require_once 'vendor/autoload.php';
Twig_Autoloader::register();

$loader = new Twig_Loader_Filesystem('templates');
$twig = new Twig_Environment($loader, array(
    'cache'       => 'compilation_cache',
    'auto_reload' => true
));


echo $twig->render('Buklet.html', ['login'=>$login,'flag'=>$flag]);

