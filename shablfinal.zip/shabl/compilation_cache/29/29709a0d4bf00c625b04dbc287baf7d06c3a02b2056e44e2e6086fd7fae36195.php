<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html */
class __TwigTemplate_65deaac08dc5ce54b1a9998a8b7bc61b404932560cc9ec42ad2c50020194330f extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'title' => [$this, 'block_title'],
            'site_header' => [$this, 'block_site_header'],
            'login' => [$this, 'block_login'],
            'sectioninf' => [$this, 'block_sectioninf'],
            'maincolomn' => [$this, 'block_maincolomn'],
            'sidebar' => [$this, 'block_sidebar'],
            'footer_site' => [$this, 'block_footer_site'],
            'script' => [$this, 'block_script'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"ru\">
<head>
    <link rel=\"stylesheet\" href=\"normalize.css\">
    <link rel=\"stylesheet\" href=\"font-awesome-4.7.0/css/font-awesome.min.css\">
    ";
        // line 6
        $this->displayBlock('links', $context, $blocks);
        // line 8
        echo "    <meta charset=\"utf-8\">
    <title>";
        // line 9
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
</head>
<body>
<header class=\"site-header\">
    ";
        // line 13
        $this->displayBlock('site_header', $context, $blocks);
        // line 30
        echo "</header>
<main>
    ";
        // line 32
        $this->displayBlock('sectioninf', $context, $blocks);
        // line 34
        echo "    <div class=\"mycolomns\">
        <section class=\"col_mai\">
            ";
        // line 36
        $this->displayBlock('maincolomn', $context, $blocks);
        // line 38
        echo "        </section>
        <aside class=\"col_sidebar\">
            ";
        // line 40
        $this->displayBlock('sidebar', $context, $blocks);
        // line 58
        echo "        </aside>
    </div>
</main>
<footer id=\"footer-site\">
    ";
        // line 62
        $this->displayBlock('footer_site', $context, $blocks);
        // line 72
        echo "</footer>
</body>
</html>
";
        // line 75
        $this->displayBlock('script', $context, $blocks);
    }

    // line 6
    public function block_links($context, array $blocks = [])
    {
        // line 7
        echo "    ";
    }

    // line 9
    public function block_title($context, array $blocks = [])
    {
    }

    // line 13
    public function block_site_header($context, array $blocks = [])
    {
        // line 14
        echo "    ";
        $this->displayBlock('login', $context, $blocks);
        // line 22
        echo "    <h1><a href=\"index.php\"><img id=\"logo\" src=\"files/images/khuy.png\"></a></h1>
    <nav id=\"main-menu\">
        <ul>
            <li><a href=\"AboutUs.php\">О нас</a></li>
            <li><a href=\"Feedback.php\">Оставить отзыв</a></li>
        </ul>
    </nav>
    ";
    }

    // line 14
    public function block_login($context, array $blocks = [])
    {
        // line 15
        echo "    ";
        if ( !($context["flag"] ?? null)) {
            // line 16
            echo "    <span><a id=\"login\" href=\"LogReg.php\">Вход</a></span>
    ";
        }
        // line 18
        echo "    ";
        if (($context["flag"] ?? null)) {
            // line 19
            echo "    <span><a id=\"login\" href=\"LogReg.php\">";
            echo twig_escape_filter($this->env, ($context["login"] ?? null), "html", null, true);
            echo "</a></span>
    ";
        }
        // line 21
        echo "    ";
    }

    // line 32
    public function block_sectioninf($context, array $blocks = [])
    {
        // line 33
        echo "    ";
    }

    // line 36
    public function block_maincolomn($context, array $blocks = [])
    {
        // line 37
        echo "            ";
    }

    // line 40
    public function block_sidebar($context, array $blocks = [])
    {
        // line 41
        echo "            <div class=\"container-form\">
                <form type=\"get\" action=\"\">
                    <input type=\"text\" id=\"serchform\" name=\"search\" placeholder=\"Поиск\">
                    <button id=\"submitsbut\">
                        <i class=\"fa fa-search\"></i>
                    </button>
                </form>
            </div>
            <div class=\"categorycontainer\">
                <ul class=\"category\">
                    <li><a href=\"Buklet.php\">Буклеты</a></li>
                    <li><a href=\"Flaer.php\">Флаеры</a></li>
                    <li><a href=\"Vizitka.php\">Визитки</a></li>
                    <li><a href=\"FBcs.php\">Отзывы</a></li>
                </ul>
            </div>
            ";
    }

    // line 62
    public function block_footer_site($context, array $blocks = [])
    {
        // line 63
        echo "    <ul class=\"soc\">
        <li><a href=\"https://vk.com/id282515795\" class=\"fa fa-vk\"></a></li>
        <li><a href=\"https://ru-ru.facebook.com/davidkarolinskii\" class=\"fa fa-facebook\"></a></li>
        <li><a href=\"\" class=\"fa fa-mail-forward\"></a></li>
    </ul>
    <div>
        <span>&copy; Давид Каролинсий 2020</span>
    </div>
    ";
    }

    // line 75
    public function block_script($context, array $blocks = [])
    {
    }

    public function getTemplateName()
    {
        return "index.html";
    }

    public function getDebugInfo()
    {
        return array (  199 => 75,  187 => 63,  184 => 62,  164 => 41,  161 => 40,  157 => 37,  154 => 36,  150 => 33,  147 => 32,  143 => 21,  137 => 19,  134 => 18,  130 => 16,  127 => 15,  124 => 14,  113 => 22,  110 => 14,  107 => 13,  102 => 9,  98 => 7,  95 => 6,  91 => 75,  86 => 72,  84 => 62,  78 => 58,  76 => 40,  72 => 38,  70 => 36,  66 => 34,  64 => 32,  60 => 30,  58 => 13,  51 => 9,  48 => 8,  46 => 6,  39 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "index.html", "/home/david/PhpstormProjects/shabl/templates/index.html");
    }
}
