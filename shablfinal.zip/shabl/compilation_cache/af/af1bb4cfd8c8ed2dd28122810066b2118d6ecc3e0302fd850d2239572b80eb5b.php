<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* register.html */
class __TwigTemplate_e532ebca7c8be7e616ba6eb104d9782879f57d4e29de9bf5d24acd7f26ee99cf extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'maincolomn' => [$this, 'block_maincolomn'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "LogReg.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("LogReg.html", "register.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        echo "Регистрация";
    }

    // line 3
    public function block_maincolomn($context, array $blocks = [])
    {
        // line 4
        echo "
<div class=\"logreg\">



<form action=\"../vendor2/signup.php\" method=\"post\" enctype=\"multipart/form-data\">
    <label>ФИО</label>
    <input type=\"text\" name=\"full_name\" placeholder=\"Введите свое полное имя\">
    <label>Логин</label>
    <input type=\"text\" name=\"login\" placeholder=\"Введите свой логин\">
    <label>Почта</label>
    <input type=\"email\" name=\"email\" placeholder=\"Введите адрес своей почты\">
    <label>Изображение профиля</label>
    <input type=\"file\" name=\"avatar\">
    <label>Пароль</label>
    <input type=\"password\" name=\"password\" placeholder=\"Введите пароль\">
    <label>Подтверждение пароля</label>
    <input type=\"password\" name=\"password_confirm\" placeholder=\"Подтвердите пароль\">
    <button type=\"submit\">Зарегистрироваться</button>
    <p>
        У вас уже есть аккаунт? - <a href=\"/\">Авторизируйтесь</a>!
    </p>
            ";
        // line 26
        if (($context["message"] ?? null)) {
            // line 27
            echo "                <p class=\"msg\">";
            echo twig_escape_filter($this->env, ($context["message"] ?? null), "html", null, true);
            echo "</p>
            ";
        }
        // line 29
        echo "</form>

</div>
";
    }

    public function getTemplateName()
    {
        return "register.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 29,  75 => 27,  73 => 26,  49 => 4,  46 => 3,  40 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "register.html", "/home/david/PhpstormProjects/shabl/templates/register.html");
    }
}
