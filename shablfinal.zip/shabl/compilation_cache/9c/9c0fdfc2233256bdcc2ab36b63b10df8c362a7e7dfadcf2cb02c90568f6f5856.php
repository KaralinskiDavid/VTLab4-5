<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Vizitka.html */
class __TwigTemplate_a26d123d576f48417d3f759c7e0565c27d43ff69e9d84e619250ed7e3bcc5a14 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'title' => [$this, 'block_title'],
            'sectioninf' => [$this, 'block_sectioninf'],
            'text' => [$this, 'block_text'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "Buklet.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("Buklet.html", "Vizitka.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_links($context, array $blocks = [])
    {
        // line 3
        echo "    <link rel=\"stylesheet\" href=\"FirstPg.css\">
    <link rel=\"stylesheet\" href=\"Feedback.css\">
    <link rel=\"stylesheet\" href=\"Buklet.css\">
    <link rel=\"stylesheet\" href=\"Flaer.css\">
    <link rel=\"stylesheet\" href=\"Vizitka.css\">
";
    }

    // line 9
    public function block_title($context, array $blocks = [])
    {
        echo "Визитки";
    }

    // line 10
    public function block_sectioninf($context, array $blocks = [])
    {
    }

    // line 12
    public function block_text($context, array $blocks = [])
    {
        // line 13
        echo "    <div class=\"infotext\">
        <h1>Немного о визитках</h1>
        <p>
            В типографии PIX можно заказать визитки недорого, учитывая скидки и акции компании.<br>
            Мы печатаем визитки на плотной бумаге, изготовленной в Германии. Для получения продукции высокого<br>
            качества используется профессиональное цифровое оборудование — печатная машина Konica Minolta<br>
            bizhub PRESS C1070.  Доступна печать визиток на дизайнерской бумаге, на крафт бумаге и других оригинальных поверхностях.
        </p>
        <p>
            Срок изготовления — от одного дня, если продукция не отличается сложным макетом.
        </p>
        <p>
            Обращаем ваше внимание, что у каждого из Клиентов есть возможность заказать визитки по акции.<br>
            Сегодня дешево обойдется печать двухсторонних офсетных визиток по цене односторонних.<br>
            Бесплатно осуществляется ламинация лицевой стороны продукции. Срок изготовления — 7 рабочих дней.
        </p>
    </div>
    ";
    }

    public function getTemplateName()
    {
        return "Vizitka.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 13,  65 => 12,  60 => 10,  54 => 9,  45 => 3,  42 => 2,  32 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "Vizitka.html", "/home/david/PhpstormProjects/shabl/templates/Vizitka.html");
    }
}
