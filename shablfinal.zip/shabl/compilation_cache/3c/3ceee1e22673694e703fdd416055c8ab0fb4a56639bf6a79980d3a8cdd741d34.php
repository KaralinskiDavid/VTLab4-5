<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* FBcs.html */
class __TwigTemplate_54afbe911f966780af4019523de6fb6d04716bde09663d11bf428a98ee32b799 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'title' => [$this, 'block_title'],
            'maincolomn' => [$this, 'block_maincolomn'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "index.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("index.html", "FBcs.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_links($context, array $blocks = [])
    {
        // line 3
        echo "    <link rel=\"stylesheet\" href=\"FirstPg.css\">
    <link rel=\"stylesheet\" href=\"FBcs.css\">
";
    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        echo "Отзывы";
    }

    // line 7
    public function block_maincolomn($context, array $blocks = [])
    {
        // line 8
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["feedback"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["feedbackitem"]) {
            // line 9
            echo "        ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["feedbackitem"], "OrderNum", [], "array"), "html", null, true);
            echo "<br>
        ";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["feedbackitem"], "Quality", [], "array"), "html", null, true);
            echo "<br>
        ";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($context["feedbackitem"], "Opinion", [], "array"), "html", null, true);
            echo "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['feedbackitem'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "FBcs.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 11,  69 => 10,  64 => 9,  59 => 8,  56 => 7,  50 => 6,  44 => 3,  41 => 2,  31 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "FBcs.html", "/home/david/PhpstormProjects/shabl/templates/FBcs.html");
    }
}
