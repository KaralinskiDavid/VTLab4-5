<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* profile.html */
class __TwigTemplate_eea4fb7eeb6a2d95abd7c04746c3e3c36b9951c3e3f6bd98ae29d4de3e12a3cf extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'maincolomn' => [$this, 'block_maincolomn'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "LogReg.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("LogReg.html", "profile.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        echo "Профиль";
    }

    // line 3
    public function block_maincolomn($context, array $blocks = [])
    {
        // line 4
        echo "
    <div class=\"logreg\">

        <form>
            <img src=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["uimage"] ?? null), "html", null, true);
        echo "\" width=\"200\" alt=\"\">
            <h2 style=\"margin: 10px 0;\">";
        // line 9
        echo twig_escape_filter($this->env, ($context["full_name"] ?? null), "html", null, true);
        echo "</h2>
            <a href=\"#\">";
        // line 10
        echo twig_escape_filter($this->env, ($context["email"] ?? null), "html", null, true);
        echo "</a>
            <a href=\"vendor2/logout.php\" class=\"logout\">Выход</a>
        </form>

    </div>
";
    }

    public function getTemplateName()
    {
        return "profile.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 10,  59 => 9,  55 => 8,  49 => 4,  46 => 3,  40 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "profile.html", "/home/david/PhpstormProjects/shabl/templates/profile.html");
    }
}
