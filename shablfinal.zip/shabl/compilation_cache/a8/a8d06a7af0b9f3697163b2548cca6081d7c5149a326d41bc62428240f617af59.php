<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* LogReg.html */
class __TwigTemplate_9955671aa8a7f995e8da4301f2bfa87cb07a80e999472d796e9af8dad2a9b1ca extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'title' => [$this, 'block_title'],
            'maincolomn' => [$this, 'block_maincolomn'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "index.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("index.html", "LogReg.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_links($context, array $blocks = [])
    {
        // line 3
        echo "    <link rel=\"stylesheet\" href=\"FirstPg.css\">
    <link rel=\"stylesheet\" href=\"assets/css/main.css\">
";
    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        echo "Авторизация";
    }

    // line 7
    public function block_maincolomn($context, array $blocks = [])
    {
        // line 8
        echo "<div class=\"logreg\">



<form action=\"vendor2/signin.php\" method=\"post\">
    <label>Логин</label>
    <input type=\"text\" name=\"login\" placeholder=\"Введите свой логин\">
    <label>Пароль</label>
    <input type=\"password\" name=\"password\" placeholder=\"Введите пароль\">
    <button type=\"submit\">Войти</button>
    <p>
        У вас нет аккаунта? - <a href=\"../register.php\">Зарегистрируйтесь</a>!
    </p>
            ";
        // line 21
        if (($context["message"] ?? null)) {
            // line 22
            echo "                <p class=\"msg\">";
            echo twig_escape_filter($this->env, ($context["message"] ?? null), "html", null, true);
            echo "</p>
            ";
        }
        // line 24
        echo "</form>

</div>
";
    }

    public function getTemplateName()
    {
        return "LogReg.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 24,  76 => 22,  74 => 21,  59 => 8,  56 => 7,  50 => 6,  44 => 3,  41 => 2,  31 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "LogReg.html", "/home/david/PhpstormProjects/shabl/templates/LogReg.html");
    }
}
