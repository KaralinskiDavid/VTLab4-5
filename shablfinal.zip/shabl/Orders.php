<?php
require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';
require 'phpmailer/Exception.php';

$feedback=array();



$feedback["Email"]=htmlentities($_POST["eMail"]);
$email=$_POST["eMail"];
$feedback["PaperType"]=htmlentities($_POST["papertype"]);
$feedback["Size"]=$_POST["size"];
$feedback["Opinion"]=htmlentities($_POST["feedbacktext"]);


if (($_SERVER["HTTP_REFERER"][strlen($_SERVER["HTTP_REFERER"])-5])=='t')
{
    $firstletters="BU";
}
elseif (($_SERVER["HTTP_REFERER"][strlen($_SERVER["HTTP_REFERER"])-5])=='r')
{
    $firstletters="FL";
}
else
{
    $firstletters="VI";
}

    $lastletters="TP";



$dsn = "mysql:host=localhost;port=3306;dbname=feedback;charset=utf8";


$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_NUM
];

$pdo = new PDO($dsn, 'login', 'password', $options);
$pdo->query("SET NAMES utf8");
$pdo->query("SET CHARACTER SET utf8");
$pdo->query("SET character_set_client = utf8");
$pdo->query("SET character_set_connection = utf8");
$pdo->query("SET character_set_results = utf8");

$stmt = $pdo->query("SELECT * FROM orders WHERE id =(SELECT MAX(id) FROM orders) ");
$result=$stmt->fetch();

function ninedigit($eightnum)
{
    $multiple=array(8,6,4,2,3,5,9,7);
    $index=0;
    $sum=0;
    foreach ($multiple as $multip) {
        $sum=+$multip*$eightnum[$index];
        $index++;
    }
    $ost=$sum % 11;
    $nd=11-$ost;
    if($nd==10){return 0;}
    if($nd==11){return 5;}
    return $nd;


}

function to8string($mystr)
{
  if(strlen($mystr)<8)
  {
      $count=8-strlen($mystr);
      for($i=0;$i<$count;$i++)
      {
        $mystr='0'.$mystr;
      }
  }
    return $mystr;
}

    $prevfullnumb = substr($result[5],2,9);

    if ($prevfullnumb) {
        $numb = $prevfullnumb + 1;
        $mystr=(string)$numb;
        $mystr=to8string($mystr);
        $nd=ninedigit($mystr);
        $NumOrd=$firstletters.$mystr.$nd.$lastletters;

    }else {
        $NumOrd = $firstletters ."000000005". $lastletters;
    }


$stmt = $pdo->prepare("INSERT INTO orders(name, papertype, size, comment, ordernum) VALUES(?, ?, ?, ?, ?)");
$stmt->execute([$feedback["Email"],$feedback["PaperType"],$feedback["Size"],$feedback["Opinion"],$NumOrd]);

if (filter_var($email, FILTER_VALIDATE_EMAIL)) {

    $mail = new PHPMailer\PHPMailer\PHPMailer();
    try {
        $msg = "ok";
        $mail->isSMTP();
        $mail->CharSet = "UTF-8";
        $mail->SMTPAuth   = true;

        // Настройки почты
        $mail->Host       = 'smtp.gmail.com'; // SMTP сервера
        $mail->Username   = 'dkarolinski10'; // Логин на почте
        $mail->Password   = '26032001A'; // Пароль на почте
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;
        $mail->setFrom('dkarolinski10@mail.com', 'Типография PIX'); // Адрес самой почты

        // Получатель письма
        $mail->addAddress($_POST["eMail"]);


        // -----------------------
        // Само письмо
        // -----------------------
        $mail->isHTML(true);

        $mail->Subject = 'Cпасибо за заказ!';
        $mail->Body    = "<b>Номер вашего заказа: $NumOrd</b><br>$text";


//отравленность сообщения
        if ($mail->send()) {
            //echo "$msg";
        } else {
            echo "Сообщение не было отправлено. Неверно указаны настройки вашей почты";
        }

    } catch (Exception $e) {
        echo "Сообщение не было отправлено. Причина ошибки: {$mail->ErrorInfo}";
    }

} else {
    echo 'mailerror';
}


require_once 'vendor/autoload.php';
Twig_Autoloader::register();

$loader = new Twig_Loader_Filesystem('templates');
$twig = new Twig_Environment($loader, array(
    'cache'       => 'compilation_cache',
    'auto_reload' => true
));

$text="Заказ выполнен! Номер вашего заказа: $NumOrd";
$link=$_SERVER["HTTP_REFERER"];

echo $twig->render('AfterForm.html', ['text'=>$text, 'link'=>$link]);