<?php

    session_start();
    require_once 'connect.php';

    $login = $_POST['login'];
    $password = md5($_POST['password']);


    $check_user = $pdo->query( "SELECT * FROM `users` WHERE `login` = '$login' AND `password` = '$password'");
    if (($check_user->rowCount()) > 0) {

        $user = $check_user->fetch();

        $_SESSION['user'] = [
            "id" => $user['id'],
            "full_name" => $user['full_name'],
            "avatar" => $user['avatar'],
            "email" => $user['email'],
            "login"=>$user['login'],
            "delcomid"=>0
        ];

        header('Location: ../profile.php');

    } else {
        $_SESSION['message'] = 'Неверный логин или пароль';
        header('Location: ../LogReg.php');
    }
    ?>

<pre>
    <?php
    print_r($check_user);
    print_r($user);
    ?>
</pre>
