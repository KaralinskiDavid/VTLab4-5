<?php

//session_save_path("SESS");
session_start();

if ($_SESSION['user']) {
    header('Location: profile.php');
}


require_once 'vendor/autoload.php';
Twig_Autoloader::register();

$loader = new Twig_Loader_Filesystem('templates');
$twig = new Twig_Environment($loader, array(
    'cache' => 'compilation_cache',
    'auto_reload' => true
));


echo $twig->render('LogReg.html', ['message'=>$_SESSION["message"]]);

unset($_SESSION['message']);

