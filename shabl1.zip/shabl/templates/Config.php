<?php
    return[
        'host'=>'localhost';
        'dbname'=>'test_pdo';
        'username'=>'root';
        'password'=>'';
        'charset'=>'utf-8';
]