<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html */
class __TwigTemplate_65deaac08dc5ce54b1a9998a8b7bc61b404932560cc9ec42ad2c50020194330f extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'title' => [$this, 'block_title'],
            'site_header' => [$this, 'block_site_header'],
            'sectioninf' => [$this, 'block_sectioninf'],
            'maincolomn' => [$this, 'block_maincolomn'],
            'sidebar' => [$this, 'block_sidebar'],
            'footer_site' => [$this, 'block_footer_site'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"ru\">
<head>
    <link rel=\"stylesheet\" href=\"normalize.css\">
    <link rel=\"stylesheet\" href=\"font-awesome-4.7.0/css/font-awesome.min.css\">
    ";
        // line 6
        $this->displayBlock('links', $context, $blocks);
        // line 8
        echo "    <meta charset=\"utf-8\">
    <title>";
        // line 9
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
</head>
<body>
<header class=\"site-header\">
    ";
        // line 13
        $this->displayBlock('site_header', $context, $blocks);
        // line 22
        echo "</header>
<main>
    ";
        // line 24
        $this->displayBlock('sectioninf', $context, $blocks);
        // line 26
        echo "    <div class=\"mycolomns\">
        <section class=\"col_mai\">
            ";
        // line 28
        $this->displayBlock('maincolomn', $context, $blocks);
        // line 30
        echo "        </section>
        <aside class=\"col_sidebar\">
            ";
        // line 32
        $this->displayBlock('sidebar', $context, $blocks);
        // line 50
        echo "        </aside>
    </div>
</main>
<footer id=\"footer-site\">
    ";
        // line 54
        $this->displayBlock('footer_site', $context, $blocks);
        // line 64
        echo "</footer>
</body>
</html>";
    }

    // line 6
    public function block_links($context, array $blocks = [])
    {
        // line 7
        echo "    ";
    }

    // line 9
    public function block_title($context, array $blocks = [])
    {
    }

    // line 13
    public function block_site_header($context, array $blocks = [])
    {
        // line 14
        echo "    <h1><a href=\"index.php\"><img id=\"logo\" src=\"files/images/khuy.png\"></a></h1>
    <nav id=\"main-menu\">
        <ul>
            <li><a href=\"AboutUs.php\">О нас</a></li>
            <li><a href=\"Feedback.php\">Оставить отзыв</a></li>
        </ul>
    </nav>
    ";
    }

    // line 24
    public function block_sectioninf($context, array $blocks = [])
    {
        // line 25
        echo "    ";
    }

    // line 28
    public function block_maincolomn($context, array $blocks = [])
    {
        // line 29
        echo "            ";
    }

    // line 32
    public function block_sidebar($context, array $blocks = [])
    {
        // line 33
        echo "            <div class=\"container-form\">
                <form type=\"get\" action=\"\">
                    <input type=\"text\" id=\"serchform\" name=\"search\" placeholder=\"Поиск\">
                    <button id=\"submitsbut\">
                        <i class=\"fa fa-search\"></i>
                    </button>
                </form>
            </div>
            <div class=\"categorycontainer\">
                <ul class=\"category\">
                    <li><a href=\"Buklet.php\">Буклеты</a></li>
                    <li><a href=\"Flaer.php\">Флаеры</a></li>
                    <li><a href=\"Vizitka.php\">Визитки</a></li>
                    <li><a href=\"FBcs.php\">Отзывы</a></li>
                </ul>
            </div>
            ";
    }

    // line 54
    public function block_footer_site($context, array $blocks = [])
    {
        // line 55
        echo "    <ul class=\"soc\">
        <li><a href=\"https://vk.com/id282515795\" class=\"fa fa-vk\"></a></li>
        <li><a href=\"https://ru-ru.facebook.com/davidkarolinskii\" class=\"fa fa-facebook\"></a></li>
        <li><a href=\"\" class=\"fa fa-mail-forward\"></a></li>
    </ul>
    <div>
        <span>&copy; Давид Каролинсий 2020</span>
    </div>
    ";
    }

    public function getTemplateName()
    {
        return "index.html";
    }

    public function getDebugInfo()
    {
        return array (  156 => 55,  153 => 54,  133 => 33,  130 => 32,  126 => 29,  123 => 28,  119 => 25,  116 => 24,  105 => 14,  102 => 13,  97 => 9,  93 => 7,  90 => 6,  84 => 64,  82 => 54,  76 => 50,  74 => 32,  70 => 30,  68 => 28,  64 => 26,  62 => 24,  58 => 22,  56 => 13,  49 => 9,  46 => 8,  44 => 6,  37 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "index.html", "/home/david/PhpstormProjects/shabl/templates/index.html");
    }
}
