<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* FBcs.html.twig */
class __TwigTemplate_1944bd6cabd02841fcb347f4d7d025e87076305b981731e5f871c3c2760a2199 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'title' => [$this, 'block_title'],
            'maincolomn' => [$this, 'block_maincolomn'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "index.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("index.html", "FBcs.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_links($context, array $blocks = [])
    {
        // line 3
        echo "    <link rel=\"stylesheet\" href=\"FirstPg.css\">
    <link rel=\"stylesheet\" href=\"FBcs.css\">
";
    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        echo "Отзывы";
    }

    // line 7
    public function block_maincolomn($context, array $blocks = [])
    {
        // line 8
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["results"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["result"]) {
            // line 9
            echo "    <div class=\"FBcs\">
        <span class=\"username\">";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["result"], 1, [], "array"), "html", null, true);
            echo "</span>
        <span class=\"quality\">
            ";
            // line 12
            if (($this->getAttribute($context["result"], 2, [], "array") == 1)) {
                // line 13
                echo "                <i class=\"fa fa-star\"></i>
                 <i class=\"fa fa-star-o\"></i>
                 <i class=\"fa fa-star-o\"></i>
                 <i class=\"fa fa-star-o\"></i>
                 <i class=\"fa fa-star-o\"></i>
            ";
            }
            // line 19
            echo "            ";
            if (($this->getAttribute($context["result"], 2, [], "array") == 2)) {
                // line 20
                echo "                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star-o\"></i>
                <i class=\"fa fa-star-o\"></i>
                <i class=\"fa fa-star-o\"></i>
            ";
            }
            // line 26
            echo "            ";
            if (($this->getAttribute($context["result"], 2, [], "array") == 3)) {
                // line 27
                echo "                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star-o\"></i>
                <i class=\"fa fa-star-o\"></i>
            ";
            }
            // line 33
            echo "            ";
            if (($this->getAttribute($context["result"], 2, [], "array") == 4)) {
                // line 34
                echo "                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star-o\"></i>
            ";
            }
            // line 40
            echo "            ";
            if (($this->getAttribute($context["result"], 2, [], "array") == 5)) {
                // line 41
                echo "                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star\"></i>
                <i class=\"fa fa-star\"></i>
            ";
            }
            // line 47
            echo "        </span>
        <br>
        <p class=\"Opinion\">
            <blockquote>";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($context["result"], 4, [], "array"), "html", null, true);
            echo "</blockquote>
        </p>
    </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['result'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "FBcs.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  131 => 50,  126 => 47,  118 => 41,  115 => 40,  107 => 34,  104 => 33,  96 => 27,  93 => 26,  85 => 20,  82 => 19,  74 => 13,  72 => 12,  67 => 10,  64 => 9,  59 => 8,  56 => 7,  50 => 6,  44 => 3,  41 => 2,  31 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "FBcs.html.twig", "/home/david/PhpstormProjects/shabl/templates/FBcs.html.twig");
    }
}
