<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* AfterForm.html */
class __TwigTemplate_ab28b2e723c0cecb6f7a1cd17363ae5b87c31cb257342372e3306c49c1af5142 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'maincolomn' => [$this, 'block_maincolomn'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "index.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("index.html", "AfterForm.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_links($context, array $blocks = [])
    {
        // line 4
        echo "    <link rel=\"stylesheet\" href=\"FirstPg.css\">
    <link rel=\"stylesheet\" href=\"AfterForm.css\">
";
    }

    // line 8
    public function block_maincolomn($context, array $blocks = [])
    {
        // line 9
        echo "    <div id=\"AfterForm\">
        <p>";
        // line 10
        echo twig_escape_filter($this->env, ($context["text"] ?? null), "html", null, true);
        echo "</p>
        <a id=\"link\" href=";
        // line 11
        echo twig_escape_filter($this->env, ($context["link"] ?? null), "html", null, true);
        echo ">Назад</a>
    </div>
";
    }

    public function getTemplateName()
    {
        return "AfterForm.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 11,  55 => 10,  52 => 9,  49 => 8,  43 => 4,  40 => 3,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "AfterForm.html", "/home/david/PhpstormProjects/shabl/templates/AfterForm.html");
    }
}
